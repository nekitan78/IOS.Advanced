//
//  SocialMediaApp.swift
//  SocialMedia
//
//  Created by BMK on 20.02.2025.
//

import SwiftUI

@main
struct SocialMediaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
