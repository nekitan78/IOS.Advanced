import UIKit

struct Hobby {
    let imageName: String
    let title: String
    let description: String
}

class InterestsHobbiesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    let hobbies: [Hobby] = [
        Hobby(imageName: "formula1", title: "Формула-1", description: "Любовь к гонкам, стратегиям и скорости."),
        Hobby(imageName: "gym", title: "Спортзал", description: "Поддержка физической формы и дисциплины."),
        Hobby(imageName: "music_walks", title: "Прогулки с музыкой", description: "Расслабление и размышления под любимые треки.")
    ]
    
    let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "Интересы и Хобби"
        label.font = UIFont.boldSystemFont(ofSize: 24)
        label.textColor = .blue
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    let tableView: UITableView = {
        let tableView = UITableView()
        tableView.backgroundColor = .white
        tableView.translatesAutoresizingMaskIntoConstraints = false
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
    }
    
    private func setupUI() {
        view.addSubview(titleLabel)
        view.addSubview(tableView)
        
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(HobbyCell.self, forCellReuseIdentifier: "HobbyCell")
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            titleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            tableView.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 10),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    // MARK: - UITableViewDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return hobbies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HobbyCell", for: indexPath) as! HobbyCell
        cell.configure(with: hobbies[indexPath.row])
        return cell
    }
}
