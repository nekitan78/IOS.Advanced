import UIKit

class GoalsDreamsViewController: UIViewController {

    let scrollView = UIScrollView()
    let contentView = UIView()

    let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "Достижения и Цели"
        label.font = UIFont.boldSystemFont(ofSize: 24)
        label.textColor = .blue
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    let achievementsLabel: UILabel = createSectionLabel(text: "Достижения")
    let goalsLabel: UILabel = createSectionLabel(text: "Цели")

    let achievementsTextView: UITextView = {
        let textView = createTextView(text: """
        • Кандидат в мастера спорта по жиму лёжа.
        • Участвовал в нескольких гонках на картинге.
        • Регулярно занимаюсь в спортзале и улучшаю свою форму.
        """)
        return textView
    }()

    let goalsTextView: UITextView = {
        let textView = createTextView(text: """
        • Посетить этап Формулы-1 в Монако.
        • Стать тренером или консультантом по фитнесу.
        • Покорить Айронмен.
        • Путешествовать и вдохновляться новыми местами.
        """)
        return textView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
    }

    private func setupUI() {
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        contentView.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(scrollView)
        scrollView.addSubview(contentView)

        contentView.addSubview(titleLabel)
        contentView.addSubview(achievementsLabel)
        contentView.addSubview(achievementsTextView)
        contentView.addSubview(goalsLabel)
        contentView.addSubview(goalsTextView)

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),

            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor),

            titleLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 20),
            titleLabel.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),

            achievementsLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 20),
            achievementsLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),

            achievementsTextView.topAnchor.constraint(equalTo: achievementsLabel.bottomAnchor, constant: 10),
            achievementsTextView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            achievementsTextView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),

            goalsLabel.topAnchor.constraint(equalTo: achievementsTextView.bottomAnchor, constant: 20),
            goalsLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),

            goalsTextView.topAnchor.constraint(equalTo: goalsLabel.bottomAnchor, constant: 10),
            goalsTextView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            goalsTextView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            goalsTextView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -20)
        ])
    }

    private static func createSectionLabel(text: String) -> UILabel {
        let label = UILabel()
        label.text = text
        label.font = UIFont.boldSystemFont(ofSize: 20)
        label.textColor = .blue
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }

    private static func createTextView(text: String) -> UITextView {
        let textView = UITextView()
        textView.text = text
        textView.font = UIFont.systemFont(ofSize: 18)
        textView.textColor = .blue
        textView.backgroundColor = .clear
        textView.isEditable = false
        textView.isScrollEnabled = false
        textView.translatesAutoresizingMaskIntoConstraints = false
        return textView
    }
}
