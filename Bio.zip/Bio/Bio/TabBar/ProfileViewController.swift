import UIKit

class ProfileViewController: UIViewController {

    let profileImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "profile") // Добавь фото в Assets.xcassets
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = 50
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()

    let nameLabel: UILabel = {
        let label = UILabel()
        label.text = "Андрющенко Никита"
        label.font = UIFont.boldSystemFont(ofSize: 22)
        label.textColor = .blue
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    let birthDateLabel: UILabel = {
        let label = UILabel()
        label.text = "Дата рождения: 2005"
        label.font = UIFont.systemFont(ofSize: 18)
        label.textColor = .blue
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    let bioTextView: UITextView = {
        let textView = UITextView()
        textView.text = """
        Никита Андрющенко — 20 лет, родился в Караганде.
        Любит Формулу-1 и спортзал.
        Увлекается автомобилями и соревнованиями на выносливость.
        Работает над своим телом и силой воли.
        Ценит дисциплину и постоянное развитие.
        """
        textView.font = UIFont.systemFont(ofSize: 16)
        textView.textColor = .blue
        textView.backgroundColor = .clear
        textView.isEditable = false
        textView.isScrollEnabled = true
        textView.translatesAutoresizingMaskIntoConstraints = false
        return textView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
    }

    private func setupUI() {
        view.addSubview(profileImageView)
        view.addSubview(nameLabel)
        view.addSubview(birthDateLabel)
        view.addSubview(bioTextView)

        NSLayoutConstraint.activate([
            profileImageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            profileImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            profileImageView.widthAnchor.constraint(equalToConstant: 100),
            profileImageView.heightAnchor.constraint(equalToConstant: 100),

            nameLabel.topAnchor.constraint(equalTo: profileImageView.bottomAnchor, constant: 10),
            nameLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),

            birthDateLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 5),
            birthDateLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),

            bioTextView.topAnchor.constraint(equalTo: birthDateLabel.bottomAnchor, constant: 15),
            bioTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            bioTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            bioTextView.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            bioTextView.heightAnchor.constraint(equalToConstant: 150) // Фиксируем высоту, чтобы не было слишком много пустоты
        ])
    }
}
